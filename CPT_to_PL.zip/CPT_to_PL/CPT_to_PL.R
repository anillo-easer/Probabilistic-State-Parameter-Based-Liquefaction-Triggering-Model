# ============================================================
# Liquefaction Triggering
# This script reproduces the CPT-based probabilistic workflow used in our liquefaction-triggering study:
# resistance CRR(ψ) combined with Monte Carlo propagation of CPT-derived state parameter ψ (Plewes-type),
# and probabilistic seismic demand CSR, to compute P_L versus depth.
#
# Acknowledgment:
# This study was supported by Chile’s National Agency for Research and Development (ANID) through the
# BECAS/MAGÍSTER NACIONAL program (Grant 22240930) and the Anillo EASER—Evolution Assessment of Seismic Risk
# (Grant ACT240044). .
#
# HOW TO USE
# 1) Set working directory to the folder that contains: CPT.xlsx, 
#    CRR_model.RData, CSR_model.RData, and PSI_uncertainty.RData.
#    e.g. setwd("C:/Users/X/Downloads/CPT_to_PL")
# 2) Edit: GWT (m), amax, Mw, n_mc, and (optional) K0_user, Mtc_user, a_ratio_user.
# 3) Run. Output: CPT_profile_panels.png in the same folder.
# ============================================================

# -----------------------------
# A) USER INPUTS
# -----------------------------
GWT  <- 3.0       # Groundwater table depth (m)
amax <- 0.10      # Peak horizontal acceleration (g)
Mw   <- 8.0       # Moment magnitude
n_mc <- 1e4       # Monte Carlo samples, 1e4 recommended

# Optional: if known, set K0_user and/or Mtc_user (scalar or length n_mc). If unknown: keep FALSE.
K0_user  <- FALSE  # e.g., 0.60, or FALSE
Mtc_user <- FALSE  # e.g., 1.20, or FALSE

# Optional: CPT area ratio for qt correction (0–1). If unknown: keep FALSE -> a_ratio = 1.0 (qt = qc).
a_ratio_user <- FALSE





# -----------------------------
# B) PACKAGES + REQUIRED FILES
# -----------------------------
if (!requireNamespace("readxl", quietly = TRUE)) install.packages("readxl")
library(readxl)

load("CRR_model.RData")
load("CSR_model.RData")
load("PSI_uncertainty.RData")

# -----------------------------
# C) HELPERS
# -----------------------------
pick_col <- function(df_new, candidates) {
  col_raw <- names(df_new)
  
  col_norm <- tolower(col_raw)
  col_norm <- gsub("\\s+", "", col_norm)
  col_norm <- gsub("[\\._\\-\\(\\)\\[\\]\\%/]", "", col_norm)
  
  cand_norm <- tolower(candidates)
  cand_norm <- gsub("\\s+", "", cand_norm)
  cand_norm <- gsub("[\\._\\-\\(\\)\\[\\]\\%/]", "", cand_norm)
  
  hit <- match(cand_norm, col_norm)
  hit <- hit[!is.na(hit)]
  
  if (length(hit) == 0) {
    stop(
      "No matching column found among: ",
      paste(candidates, collapse = ", "),
      "\nAvailable columns: ",
      paste(col_raw, collapse = ", ")
    )
  }
  col_raw[hit[1]]
}

vec_from_user <- function(val, n, lo, hi, nm) {
  if (isFALSE(val)) return(runif(n, min = lo, max = hi))
  if (is.numeric(val)) {
    if (length(val) == 1L) return(rep(val, n))
    if (length(val) == n)  return(val)
    stop(sprintf("%s must be FALSE or numeric (length 1 or n_mc = %d).", nm, n))
  }
  stop(sprintf("%s must be FALSE or numeric.", nm))
}

# -----------------------------
# D) READ CPT (FIRST SHEET)
# -----------------------------
files <- list.files(getwd(), full.names = TRUE)
cpt_path <- files[grepl("^CPT\\.(xlsx|xlsm|xls)$", basename(files), ignore.case = TRUE)]
if (length(cpt_path) == 0) stop("Could not find CPT.xlsx/xlsm/xls in: ", getwd())
df_new <- read_excel(cpt_path[1], sheet = 1)

c_z  <- pick_col(df_new, c("D", "Depth", "Z", "z", "Z_mean"))
c_qc <- pick_col(df_new, c("q_c", "qc", "qc (MPa)", "qc (kPa)", "qt", "q_t", "qc = qt (mPa) Average"))
c_fs <- pick_col(df_new, c("f_s", "fs", "fs (kPa) Average", "fs (MPa)", "fs(kPa)", "fsMPa"))

cn_norm <- tolower(names(df_new))
cn_norm <- gsub("\\s+", "", cn_norm)
cn_norm <- gsub("[\\._\\-\\(\\)\\[\\]\\%/]", "", cn_norm)
has_u2  <- any(cn_norm %in% c("u2","u_2","porepressure","u2kpa","u2mpa"))
c_u2    <- if (has_u2) pick_col(df_new, c("u2", "u_2", "u2 (kPa)", "u2 (MPa)")) else NA_character_

D     <- as.numeric(df_new[[c_z]])
qc_in <- as.numeric(df_new[[c_qc]])
fs_in <- as.numeric(df_new[[c_fs]])
u2_in <- if (!is.na(c_u2)) as.numeric(df_new[[c_u2]]) else rep(NA_real_, length(D))

ok <- is.finite(D) & is.finite(qc_in) & is.finite(fs_in)
D     <- D[ok]; qc_in <- qc_in[ok]; fs_in <- fs_in[ok]; u2_in <- u2_in[ok]
n_z <- length(D)

# -----------------------------
# E) UNITS + STRESSES + CPT DERIVED (Fr, Bq, IcRW)
# -----------------------------
# Normalize qc and fs to internal kPa (qc_MPa kept for plotting)
fs_med <- median(abs(fs_in), na.rm = TRUE)
fs_kPa <- if (is.finite(fs_med) && fs_med < 2) fs_in * 1000 else fs_in

qc_med <- median(abs(qc_in), na.rm = TRUE)
if (is.finite(qc_med) && qc_med > 200) {
  qc_kPa <- qc_in
  qc_MPa <- qc_in / 1000
} else {
  qc_MPa <- qc_in
  qc_kPa <- qc_in * 1000
}

if (has_u2) {
  u2_med <- median(abs(u2_in), na.rm = TRUE)
  u2_kPa_raw <- if (is.finite(u2_med) && u2_med < 2) u2_in * 1000 else u2_in
} else {
  u2_kPa_raw <- rep(NA_real_, n_z)
}

sv0  <- D * 18.5
u0   <- pmax((D - GWT) * 9.81, 0)
sv0e <- sv0 - u0

u2_kPa <- if (has_u2) u2_kPa_raw else u0   # ensures Bq exists (Bq=0 if u2=u0)

a_ratio <- if (isFALSE(a_ratio_user) || is.na(a_ratio_user)) 1.0 else as.numeric(a_ratio_user)
if (!is.finite(a_ratio) || a_ratio < 0 || a_ratio > 1) stop("a_ratio_user must be in [0,1] or FALSE.")

qt_kPa <- qc_kPa + (1 - a_ratio) * u2_kPa

Bq <- (u2_kPa - u0) / pmax(qt_kPa - sv0, 1e-6)
Bq <- pmax(pmin(Bq, 0.99), -0.99)

Fr <- 100 * fs_kPa / pmax(qt_kPa - sv0, 1e-6)

# IcRW iterative (Robertson-style), using qt
Pa <- 101.325
n  <- rep(1, n_z)
for (it in 1:100) {
  Qtn  <- ((qt_kPa - sv0) / Pa) * (Pa / pmax(sv0e, 1e-6))^n
  IcRW <- sqrt((3.47 - log10(pmax(Qtn, 1e-12)))^2 +
                 (log10(pmax(Fr, 1e-12)) + 1.22)^2)
  n    <- pmin(0.381 * IcRW + 0.05 * (sv0e / Pa) - 0.15, 1)
  n    <- pmax(n, 0.5)
}
Qtn  <- ((qt_kPa - sv0) / Pa) * (Pa / pmax(sv0e, 1e-6))^n
IcRW <- sqrt((3.47 - log10(pmax(Qtn, 1e-12)))^2 +
               (log10(pmax(Fr, 1e-12)) + 1.22)^2)

# -----------------------------
# F) MONTE CARLO: K0, Mtc, PSI(ψ) + CRR + PL
# -----------------------------
K0_draws <- vec_from_user(K0_user,  n_mc, 0.50, 0.70, "K0_user")
Mtc      <- vec_from_user(Mtc_user, n_mc, 1.15, 1.32, "Mtc_user")

if (!exists("Bias_Plewes")) Bias_Plewes <- 0
stopifnot(exists("Sigma_PSI_Plewes"), exists("post_draws"), exists("simulate_CSR"))

psi_Plew <- matrix(NA_real_, nrow = n_z, ncol = n_mc)

for (i in seq_len(n_z)) {
  p0  <- sv0[i]  * (1 + 2*K0_draws) / 3
  p0e <- sv0e[i] * (1 + 2*K0_draws) / 3
  
  QP_BJ  <- (qt_kPa[i] - p0) / pmax(p0e, 1e-6)
  Qgroup <- ifelse(Bq[i] < 1, QP_BJ * (1 - Bq[i]) + 1, 1)
  Qgroup <- pmax(Qgroup, 1)
  
  lambda10 <- if (Fr[i] < 8.9 && Fr[i] > 0.1) Fr[i]/10 else if (Fr[i] <= 0.1) 0.01 else 0.89
  k_bar    <- Mtc * (3 + 0.85/lambda10)
  m_bar    <- 11.9 - 13.3*lambda10
  
  psi_Plew[i, ] <- -log(Qgroup / k_bar) / m_bar - Bias_Plewes
}

PSI_mc <- matrix(NA_real_, nrow = n_z, ncol = n_mc)
CRR_mc <- matrix(NA_real_, nrow = n_z, ncol = n_mc)
PL     <- rep(NA_real_, n_z)

for (i in seq_len(n_z)) {
  csr_mc <- simulate_CSR(
    a_max       = amax,
    sigma_v     = sv0[i],
    sigma_v_eff = sv0e[i],
    z           = D[i],
    Mw          = Mw,
    n_sim       = n_mc,
    w_WUS       = 0.5,
    use_coeff_se= FALSE
  )
  
  idx       <- sample.int(length(post_draws$b0_mean), n_mc, replace = TRUE)
  ln_a0     <- post_draws$b0_mean[idx] + post_draws$tau_b0[idx] * rnorm(n_mc)
  a1_mc     <- post_draws$a1_mean[idx] + post_draws$tau_a1[idx] * rnorm(n_mc)
  sigmaR_mc <- post_draws$sigma_R[idx]
  
  psi_i  <- rnorm(n_mc, mean = psi_Plew[i, ], sd = Sigma_PSI_Plewes)
  mu_ln  <- ln_a0 + a1_mc * psi_i
  ln_crr <- rnorm(n_mc, mean = mu_ln, sd = sigmaR_mc)
  crr_i  <- exp(ln_crr)
  
  PSI_mc[i, ] <- psi_i
  CRR_mc[i, ] <- crr_i
  
  f_ss <- (1 + 2*K0_draws) / 3
  FS_i <- f_ss * crr_i / pmax(csr_mc, 1e-12)
  
  PL[i] <- mean(FS_i < 1.0, na.rm = TRUE)
}

psi_med <- apply(PSI_mc, 1, median, na.rm = TRUE)
psi_p16 <- apply(PSI_mc, 1, quantile, probs = 0.16, na.rm = TRUE)
psi_p84 <- apply(PSI_mc, 1, quantile, probs = 0.84, na.rm = TRUE)

CRR_med <- apply(CRR_mc, 1, median, na.rm = TRUE)
CRR_p16 <- apply(CRR_mc, 1, quantile, probs = 0.16, na.rm = TRUE)
CRR_p84 <- apply(CRR_mc, 1, quantile, probs = 0.84, na.rm = TRUE)

# -----------------------------
# G) PLOT -> PNG
# -----------------------------
# Output PNG
out_png <- file.path(getwd(), "CPT_profile_panels.png")
png_w   <- 1800
png_h   <- 1200
png_res <- 220

png(filename = out_png, width = png_w, height = png_h, res = png_res)

y <- -D
par(
  mfrow = c(1, 6),
  yaxs  = "i",
  mar   = c(3.3, 1.2, 1.8, 0.35),
  oma   = c(0.4, 2.6, 1.2, 0.2),
  cex = 0.92, cex.axis = 0.80, cex.lab = 0.90, cex.main = 0.95,
  lwd = 0.9, tck = -0.02, mgp = c(1.8, 0.50, 0),
  family = "sans"
)

col_main <- "black"
col_unc  <- "grey60"
lwd_main <- 1.05
lwd_unc  <- 0.85

# 1) qc
plot(qc_MPa, y, type="n", xlab=expression(q[c]~"(MPa)"), ylab="", axes=FALSE)
abline(v=pretty(range(qc_MPa, na.rm=TRUE), n=5), col="grey85", lwd=0.6)
lines(qc_MPa, y, col=col_main, lwd=lwd_main, lty=1)
axis(1); axis(2, las=1); box()
points(max(qc_MPa, na.rm=TRUE)-5, -GWT, pch=25, bg="black", col="black", cex=1)

# 2) Rf
plot(Fr, y, type="n", xlab=expression(R[f]~"(%)"), ylab="", axes=FALSE)
abline(v=pretty(range(Fr, na.rm=TRUE), n=5), col="grey85", lwd=0.6)
lines(Fr, y, col=col_main, lwd=lwd_main, lty=1)
axis(1); axis(2, labels=FALSE, tck=-0.02); box()
points(max(Fr, na.rm=TRUE)-1, -GWT, pch=25, bg="black", col="black", cex=1)

# 3) Ic (SBT style)
cuts <- c(-Inf, 1.31, 2.05, 2.60, 2.95, 3.60, Inf)
xlim_fixed <- c(1.0, 4.0)
cuts_clip  <- unique(pmax(pmin(cuts, xlim_fixed[2]), xlim_fixed[1]))

band_cols <- c("#E7A34B","#C8B07A","#86C18A","#5FAE9B","#3E5F8A","#B66A3A")

plot(IcRW, y, type="n", xlab=expression(I["c,RW"]), ylab="", axes=FALSE, xlim=xlim_fixed)
ybot <- min(y, na.rm=TRUE) - 5
ytop <- max(y, na.rm=TRUE) + 5
for(i in 1:6){
  xl <- cuts_clip[i]; xr <- cuts_clip[i+1]
  if(!is.na(xl) && !is.na(xr) && xr > xl){
    rect(xleft=xl, xright=xr, ybottom=ybot, ytop=ytop, col=band_cols[i], border=NA)
  }
}
abline(v=seq(1,4,by=0.5), col="grey85", lwd=0.6)
abline(h=pretty(range(y, na.rm=TRUE), n=8), col="grey85", lwd=0.6, lty=3)
Ic_plot <- pmax(pmin(IcRW, 4.0), 1.0)
lines(Ic_plot, y, col="yellow", lwd=1.6, lty=1)
lines(IcRW, y, col=col_main, lwd=1.6, lty=1)
axis(1); axis(2, labels=FALSE, tck=-0.02); box()
points(3.6, -GWT, pch=25, bg="black", col="black", cex=1)

# 4) PSI
psi_all <- c(psi_p16, psi_p84, psi_med)
xmin <- max(-1.0, min(psi_all, na.rm=TRUE))
xmax <- min( 0.5, max(psi_all, na.rm=TRUE))
plot(psi_med, y, type="n", xlab=expression(psi), ylab="", axes=FALSE, xlim=c(xmin,xmax))
abline(v=pretty(c(xmin,xmax), n=5), col="grey85", lwd=0.6)
lines(psi_p16, y, col=col_unc, lwd=lwd_unc, lty=2)
lines(psi_p84, y, col=col_unc, lwd=lwd_unc, lty=2)
lines(psi_med, y, col=col_main, lwd=lwd_main, lty=1)
axis(1); axis(2, labels=FALSE, tck=-0.02); box()
points(xmax, -GWT, pch=25, bg="black", col="black", cex=1)

# 5) CRR (xlim max 2.0)
plot(CRR_med, y, type="n", xlab=expression(CRR(psi)), ylab="", axes=FALSE, xlim=c(0,2.0))
abline(v=seq(0,2.0,by=0.5), col="grey85", lwd=0.6)
lines(pmin(CRR_p16, 2.0), y, col=col_unc, lwd=lwd_unc, lty=2)
lines(pmin(CRR_p84, 2.0), y, col=col_unc, lwd=lwd_unc, lty=2)
lines(pmin(CRR_med, 2.0), y, col=col_main, lwd=lwd_main, lty=1)
axis(1); axis(2, labels=FALSE, tck=-0.02); box()
points(1.5, -GWT, pch=25, bg="black", col="black", cex=1)

# 6) PL
plot(PL, y, type="n", xlab=expression(P[L]), ylab="", axes=FALSE, xlim=c(0,1))
abline(v=seq(0,1,by=0.25), col="grey85", lwd=0.6)
lines(PL, y, col=col_main, lwd=lwd_main, lty=1)
axis(1); axis(2, labels=FALSE, tck=-0.02); box()
points(0.75, -GWT, pch=25, bg="black", col="black", cex=1)

mtext("Depth (m)", side=2, outer=TRUE, line=1.0, cex=0.95)
mtext("CPT profile", side=3, outer=TRUE, line=-0.75, cex=1.00)

dev.off()
message("PNG generated: ", out_png)
