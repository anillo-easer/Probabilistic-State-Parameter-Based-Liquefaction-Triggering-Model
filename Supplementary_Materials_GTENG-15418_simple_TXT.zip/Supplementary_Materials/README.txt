SUPPLEMENTARY MATERIALS
=======================

Manuscript:
Probabilistic State Parameter-Based Liquefaction Triggering Model

Authors:
Pedro Reyes
Gonzalo Montalva
Vicente San Martín
Robb Moss


FILES
=====

Supplementary_Materials_GTENG-15418.pdf
Complete supplementary document containing Figures S1 and S2.

Figure_S1.tiff
High-resolution version of Supplemental Figure S1.

Figure_S1.png
Preview version of Supplemental Figure S1 for viewing in a web browser.

Figure_S2.tiff
High-resolution version of Supplemental Figure S2.

Figure_S2.png
Preview version of Supplemental Figure S2 for viewing in a web browser.


FIGURE S1
=========

Cyclic resistance trends from compiled triaxial tests.

(a) CSR versus number of cycles, N.
(b) Normalized response CSR/CSR15 versus N, with the best-fitting curve
using the Jefferies and Been (2015) normalization.


FIGURE S2
=========

Total predictive uncertainty, sigma_T, as a function of the state parameter,
psi, comparing the population-level prediction and the material-specific
calibration for FBM-10.


NOTES
=====

The PDF is the complete supplementary document.

The TIFF files are the original high-resolution figures.

The PNG files are included as simple preview copies for GitHub and web
browsers.
